import React, { useEffect, useRef } from 'react';

export default function UserDetailsModal({ user, onClose }) {
  const modalRef = useRef(null);

  useEffect(() => {
    function onKey(e) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  useEffect(() => {
    const prev = document.activeElement;
    modalRef.current?.focus();
    return () => prev?.focus();
  }, []);

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label={`Details for ${user.name}`} onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal" ref={modalRef} tabIndex={-1}>
        <div className="modal-header">
          <div>
            <h3>{user.name}</h3>
            <p className="muted">{user.username} • {user.email}</p>
          </div>
          <button onClick={onClose} aria-label="Close">✕</button>
        </div>

        <div className="modal-body">
          <p><strong>Phone:</strong> <a href={`tel:${user.phone}`}>{user.phone}</a></p>
          <p><strong>Website:</strong> <a href={`http://${user.website}`} target="_blank" rel="noreferrer">{user.website}</a></p>
          <p><strong>Company:</strong> {user.company?.name} — <span className="muted">{user.company?.catchPhrase}</span></p>
          <p><strong>Address:</strong></p>
          <div className="muted address">
            {user.address?.suite}, {user.address?.street}, {user.address?.city} — {user.address?.zipcode}
          </div>
          <p><strong>Geo:</strong> {user.address?.geo?.lat}, {user.address?.geo?.lng}</p>
        </div>

        <div className="modal-actions">
          <button onClick={onClose} className="btn">Close</button>
        </div>
      </div>
    </div>
  );
}