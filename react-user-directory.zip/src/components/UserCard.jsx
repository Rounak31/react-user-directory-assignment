import React from 'react';

export default function UserCard({ user, onView }) {
  return (
    <article className="card">
      <div>
        <h2 className="card-title">{user.name}</h2>
        <p className="muted">{user.email}</p>
        <p className="muted">{user.company?.name}</p>
      </div>

      <div className="card-actions">
        <button onClick={onView} className="btn primary">View Details</button>
        <a href={`mailto:${user.email}`} className="btn">Email</a>
      </div>
    </article>
  );
}