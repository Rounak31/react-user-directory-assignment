import React, { useEffect, useState } from 'react';
import UserCard from './components/UserCard';
import UserDetailsModal from './components/UserDetailsModal';

export default function App() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('userdir:dark');
    if (stored) setDark(stored === 'true');
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
    localStorage.setItem('userdir:dark', dark);
  }, [dark]);

  useEffect(() => {
    setLoading(true);
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((res) => {
        if (!res.ok) throw new Error('Network response was not ok');
        return res.json();
      })
      .then((data) => {
        setUsers(data);
        setError(null);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const filtered = users.filter((u) =>
    u.name.toLowerCase().includes(search.trim().toLowerCase())
  );

  return (
    <div className="app-root">
      <div className="container">
        <header className="header">
          <h1>User Directory</h1>
          <label className="dark-toggle">
            <input
              type="checkbox"
              checked={dark}
              onChange={(e) => setDark(e.target.checked)}
              aria-label="Toggle dark mode"
            />
            <span>Dark</span>
          </label>
        </header>

        <div className="search-wrap">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search users by name..."
            aria-label="Search users by name"
          />
        </div>

        {loading && <div className="status">Loading users…</div>}
        {error && <div className="status error">Error: {error}</div>}

        {!loading && !error && (
          <section className="grid">
            {filtered.map((user) => (
              <UserCard key={user.id} user={user} onView={() => setSelectedUser(user)} />
            ))}
          </section>
        )}

        <footer className="footer">{users.length} users loaded.</footer>
      </div>

      {selectedUser && (
        <UserDetailsModal user={selectedUser} onClose={() => setSelectedUser(null)} />
      )}
    </div>
  );
}